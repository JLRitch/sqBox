## sqBox
This is a basic Python package layout implementing possibly rectangular squares and a slew of other misnomers.
Use it for a basic package template or to introduce newer Python programmers to packages and classes. 